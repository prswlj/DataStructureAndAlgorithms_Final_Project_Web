OralCare Connect - DSA Final Project (redesign)

FILES (put all in one folder)
  index.html   Page structure with accessibility labels
  style.css    Redesigned styles: Deep Teal #194350, Coral #FF8882, Peach #FFC2B4, Seafoam #9DBEB8
  script.js    Application logic, the seven DSA implementations, and the interactive DSA Laboratory

HOW TO RUN
  Open the folder in VS Code and start Live Server on index.html.
  If old styling or data appears, hard-refresh (Ctrl+Shift+R). Data is stored in localStorage
  under the key "oralcare_dsa_final_v2".

DSA IN THE PROJECT
  Array        appointment records (display, filter, sort)
  Linked List  visit history timeline
  HashSet      unique active queue IDs (JavaScript Set)
  Stack        undo of admin actions
  Queue        FIFO waiting line for approved appointments
  BST          patient ID lookup
  Graph        service categories, BFS and DFS

LAB ADDITIONS (end of script.js)
  Array search by value, animated linked-list traversal with HEAD/TAIL, BST insert,
  animated BFS/DFS, Enter/Esc shortcuts. Lab inserts are demos and are not saved.

NOT BROWSER-TESTED. Click through every page and all seven lab tabs before presenting.
